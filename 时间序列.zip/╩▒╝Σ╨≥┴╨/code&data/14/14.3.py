import pandas as pd
from statsmodels.tsa import stattools
import statsmodels.formula.api as sm

data=pd.read_csv("climate.csv",index_col=0)


data['temp_diff1']=data['temp'].diff(1)
data['trf_diff1']=data['trf'].diff(1)
data['trf_diff2']=data['trf_diff1'].diff(1)

data[['temp_diff1','trf_diff1','trf_diff2']].plot()


# test if both temp and trf are I(1) processes
# while others are I(0) processes
print("ADF test of temp:\n",stattools.adfuller(data['temp']))
print("\nADF test of temp_diff1:\n",stattools.adfuller(data['temp_diff1'][1:]))
print("\nADF test of trf:\n",stattools.adfuller(data['trf']))
print("\nADF test of trf_diff1:\n",stattools.adfuller(data['trf_diff1'][1:]))
print("\nADF test of trf_diff2:\n",stattools.adfuller(data['trf_diff2'][2:]))
print("\nADF test of volc:\n",stattools.adfuller(data['volc']))
print("\nADF test of soi:\n",stattools.adfuller(data['soi']))
print("\nADF test of amo:\n",stattools.adfuller(data['amo']))
# we can see TRF is I(2) actually


# test cointegration by EG-test
results=stattools.coint(data['temp'],data[['trf','volc','soi','amo']])
print("\n\ntest cointegration by EG-test:",results)
print("************************")
if(results[0]<results[2][1]):
    print("the two series are cointegrated:)")
else:
    print("the two series are not cointegrated:(")
print("************************")


# estimate the ECM
results = sm.ols(formula='temp ~ trf + volc + soi + amo', data = data).fit()
print(results.summary())
print("\n\nparameters:\n",results.params)
data['residual'] = data['temp']-data['trf']*results.params[1]\
                -data['volc']*results.params[2]-data['soi']*results.params[3]\
                -data['amo']*results.params[4]-results.params[0]

ECM = sm.ols(formula='temp ~ trf + volc + soi + amo + residual',data = data).fit()
print(ECM.summary())
print("\n\nparameters of ECM:\n",ECM.params)