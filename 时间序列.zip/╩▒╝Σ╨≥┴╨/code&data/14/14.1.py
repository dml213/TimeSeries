import pandas as pd
from statsmodels.tsa import stattools
import statsmodels.formula.api as sm


data=pd.read_excel('interest_rates.xlsx',index_col=0)

data['rs_diff1']=data['rs'].diff(1)
data['r20_diff1']=data['r20'].diff(1)

data.plot()

# test if both R20 and RS are really I(1) processes
print("ADF test of RS:\n",stattools.adfuller(data['rs']))
print("\nADF test of R20:\n",stattools.adfuller(data['r20']))
print("\nADF test of RS_diff1:\n",stattools.adfuller(data['rs_diff1'][1:]))
print("\nADF test of R20_diff1:\n",stattools.adfuller(data['r20_diff1'][1:]))
# it shows both R20 and RS are indeed I(1) processes

# test cointegration by EG-test
results=stattools.coint(data['rs'],data['r20'])
print("\n\ntest cointegration by EG-test:",results)
print("************************")
if(results[0]<results[2][1]):
    print("the two series are cointegrated:)")
else:
    print("the two series are not cointegrated:(")
print("************************")


# estimate the Cointegrating Relationship by OLS
# RS~R20
results = sm.ols(formula='rs ~ r20',data = data).fit()
print("\n\nparameters of RS~R20:\n",results.params)
data['residual_rs'] = data['rs'] - data['r20'] * results.params[1] - results.params[0]

# R20~RS
results = sm.ols(formula='r20 ~ rs',data = data).fit()
print("\n\nparameters of R20~RS:\n",results.params)
data['residual_r20'] = data['r20'] - data['rs'] * results.params[1] - results.params[0]