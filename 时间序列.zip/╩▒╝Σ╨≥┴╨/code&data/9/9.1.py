import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols

# 读取数据
data = pd.read_excel('dataset/rainfall.xlsx', index_col=None)
rainfall = pd.DataFrame(np.sqrt(data["rainfall"]))

# 分离出月份列
date = data["date"].str.split('M', expand=True)
month = date[1]
month = pd.cut(month.astype(str).astype(int),12,labels=range(1,13))
data[1] = month

# 将月份转换为哑变量
month = pd.get_dummies(data[1], prefix="month")
data = month.join(rainfall)
print(data)

#OLS拟合
model = ols('rainfall ~ month_1+month_2+month_3+month_4+month_5+month_6'
         '+month_7+month_8+month_9+month_10+month_11+month_12 -1', data=data).fit(fit_intercept=False)
print(model.summary())

# 月降水量估计值
rainfall_estimate = round(model.params ** 2 * 10)
print(rainfall_estimate)