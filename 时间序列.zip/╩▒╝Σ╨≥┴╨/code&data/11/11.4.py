import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller,kpss
from statsmodels.tsa.arima_model import ARMA
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.linear_model import LinearRegression
from scipy.optimize import leastsq,minimize


# read data
data = pd.read_excel('./data/dollar.xlsx',index_col=0)[-900:]
diff = data.diff().dropna()
plt.figure(figsize=(16,8))
plt.plot(data)
plt.title('dollar-pounds exchange rate')
plt.show()

# fit model
model = sm.tsa.MarkovRegression(data, k_regimes=2)
res = model.fit()
res.summary()