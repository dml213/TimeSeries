import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import bds


# read data
data = pd.read_excel('./data/interest_rates.xlsx',index_col=0)['r20']
plt.figure(figsize=(16,8))
plt.plot(data)
plt.title('Long Interest Rate')
plt.show()

# BDS test
bds_statis = bds(data)
print('bds test : ',bds_statis)