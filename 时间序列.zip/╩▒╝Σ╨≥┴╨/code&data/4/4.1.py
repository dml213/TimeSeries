import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

# 读取数据
spread = pd.read_csv('interest_rates.csv',header=1,index_col=0)
dollar = pd.read_excel('dollar.xlsx',index_col=0)
#print(data.index)
date = pd.date_range('1952-03',periods=784,freq='M')
spread.index = date

print("Spread: statistic : ",adfuller(spread)[0],"   critical values:",adfuller(spread)[4])
print("Exchange: statistic : ",adfuller(dollar)[0],"   critical values:",adfuller(dollar)[4])