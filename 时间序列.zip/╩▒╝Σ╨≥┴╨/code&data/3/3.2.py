import pandas as pd
import matplotlib.pyplot as plt
from ARMA import determinate_order, ARMA_model
import warnings

warnings.filterwarnings("ignore")

# read_data
data = pd.read_excel("dataset/interest_rates.xlsx", index_col=0)

# plot
plt.show()

# determinate order
order = determinate_order(data["spread"], maxlag=5)

# model
ARMA_model = ARMA_model(data["spread"], order)

# predict
predict = ARMA_model.predict(start=0, end=830)
plt.plot(predict, 'g', label="predict")
plt.plot(data["spread"], 'r--', label="origin")
plt.legend(loc=0, ncol=1)
plt.show()
