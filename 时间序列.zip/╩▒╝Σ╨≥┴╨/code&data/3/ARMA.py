import pandas as pd
import sys
import matplotlib.pyplot as plt
import statsmodels.api as sm
import statsmodels.tsa.api as smt
from statsmodels.tsa.stattools import adfuller as adf
from statsmodels.tsa.stattools import arma_order_select_ic
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.arima_model import ARMA
from statsmodels.graphics.api import qqplot
import numpy as np


def determinate_order(timeseries,maxlag):
    best_p = 0
    best_q = 0
    best_bic = sys.maxsize
    for p in np.arange(maxlag):
        for q in np.arange(maxlag):
            model = ARMA(timeseries, order=(p, q))
            try:
                results_ARMA = model.fit(disp=-1)
            except:
                continue
            bic = results_ARMA.bic
            if bic < best_bic:
                best_p = p
                best_q = q
                best_bic = bic
        # print('第{}次完成...'.format(p + 1))
    return best_p, best_q


def ARMA_model(train, order):
    arma_model = ARMA(train, order).fit(disp=-1)  # 激活模型
    plt.plot(arma_model.predict(), 'k', label="ARMA")
    plt.plot(train, 'r--', label="origin")
    plt.legend(loc=0, ncol=1)
    plt.show()
    print(arma_model.summary())
    print('RMSE: %.4f' % np.sqrt(sum((arma_model.predict() - train) ** 2) / train.size))   
    return arma_model

