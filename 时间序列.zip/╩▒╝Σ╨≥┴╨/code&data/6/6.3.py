import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as sm

data=pd.read_excel('gdp.xlsx',use_col=[1])

def S_t(t,gamma,m,T=50):
    return pow((1+math.exp(-gamma*(t-m*T))),-1)

def estim(y,param):
    n=len(y)
    T=n/2
    gamma,m=param[0],param[1]
    
    data['t']=np.zeros(n)
    data['st']=np.zeros(n)
    for t in range(n):
        data.loc[t,('t')]=t
        data.loc[t,('st')]=S_t(t,gamma,m,T)
    
    results = sm.ols(formula='gdp ~ t + st + t*st', data = data).fit()
    data['residual'] = data['gdp']-data['t']*results.params[1]-data['st']*results.params[2]\
                    -data['t']*data['st']*results.params[3]-results.params[0]
    return results

y=data['gdp']
results=estim(data['gdp'],[0.0085,1.907])
print(results.summary())

fore=np.zeros(len(y))
fore=results.params[0]+results.params[1]*data['t']+results.params[2]*data['st']\
    +results.params[3]*data['t']*data['st']

plt.plot(fore)
plt.plot(data['gdp'])