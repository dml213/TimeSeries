import pandas as pd
from statsmodels.tsa import stattools

data=pd.read_excel('gdp.xlsx',index_col=0)


def ADF_test(df,name):
    df['diff']=df[name].copy()
    
    for i in range(100):
        results=stattools.adfuller(data['diff'][i:])
        if(results[0]<results[4]['1%']):
            print("the series are I(",str(i),")!:)")
            df['diff'].plot()
            break
        else:
            print("the series are not I(",str(i),")!:(")
        df['diff']=df['diff'].diff(1)
        
    return i

ADF_test(data,'gdp')