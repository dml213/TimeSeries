import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as sm

data=pd.read_excel('gdp.xlsx',index_col=0)

w=0.001
data['x']=np.arange(len(data))
x=data['x'].values
data['cwx']=np.cos(w*x)
data['c2wx']=np.cos(2*w*x)
data['c3wx']=np.cos(3*w*x)
data['swx']=np.sin(w*x)
data['s2wx']=np.sin(2*w*x)
data['s3wx']=np.sin(3*w*x)

results=sm.ols(formula='gdp ~ cwx + c2wx + c3wx + swx + s2wx + s3wx', data = data).fit()
print(results.summary())

fore=np.zeros(len(data))
fore=results.params[0]+results.params[1]*data['cwx']+results.params[2]*data['c2wx']\
    +results.params[3]*data['c3wx']+results.params[4]*data['swx']\
    +results.params[5]*data['s2wx']+results.params[6]*data['s3wx']

plt.plot(data['gdp'])
plt.plot(fore)
plt.legend(['observed','forecast'])