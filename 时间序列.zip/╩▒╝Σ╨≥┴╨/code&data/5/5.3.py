import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

# 读取数据
data = pd.read_excel('./wine_spirits.xlsx',index_col=0,header=None)
data.plot()

# we include the trend to excetu the ADF test
print("tau statistic : ",adfuller(data,regression='ct')[0],"   critical values:",adfuller(data,regression='ct')[4])