import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

# 读取数据
data = pd.read_excel('./global_temps.xlsx',index_col=0)
#print(data.index)
date = pd.date_range('1850-02',periods=2015,freq='M')
data.index = date
data.plot()
print("tau statistic : ",adfuller(data)[0],"   critical values:",adfuller(data)[4])