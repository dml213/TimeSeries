import pandas as pd
import numpy as np
import warnings
from statsmodels.tsa.api import VAR, SVAR
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["SimHei"]   # 用来正常显示中文标签
plt.rcParams["axes.unicode_minus"] = False     # 用来正常显示负号

# 读取数据
data = pd.read_excel('quenouille.xlsx', index_col=0)
# data.plot()
# plt.show()

# VAR模型
model = VAR(data)
results = model.fit(4)
print(results.summary())

# 残差自相关图
results.plot_acorr(6)
plt.show()

# 脉冲响应分析
irf = results.irf(10)
irf.plot(orth=False, impulse='y1')
irf.plot(orth=False, impulse='y2')
irf.plot(orth=False, impulse='y3')
irf.plot(orth=False, impulse='y4')
irf.plot(orth=False, impulse='y5')
plt.show()

# 累计脉冲响应
irf.plot_cum_effects(orth=False)
plt.show()

# 方差分解
fevd = results.fevd(5)
fevd.summary()
results.fevd(20).plot()
plt.show()


# SVAR模型
model = SVAR(data, svar_type="A",                      # A:待估计矩阵
             A=np.array([[1, 0, 0, 0, 0],
                         ['E', 1, 0, 0, 0],
                         [0, 0, 1, 0, 0],
                         [0, 0, 'E', 1, 0],
                         [0, 'E', 'E', 0, 1]]))
results = model.fit()
print(results.summary())
print("矩阵A估计为：\n", results.A)

# 累计脉冲响应
irf = results.irf(10)
irf.plot_cum_effects(orth=False)
plt.show()


