import pandas as pd
import warnings
from statsmodels.tsa.api import VAR
import matplotlib.pyplot as plt
import statsmodels.api as sm

warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["SimHei"]   # 用来正常显示中文标签
plt.rcParams["axes.unicode_minus"] = False     # 用来正常显示负号

# 读取数据
data = pd.read_excel('interest_rates.xlsx', index_col=0)

# 差分
D_data = pd.DataFrame()
D_data["drs"] = data["rs"].diff()
D_data["dr20"] = data["r20"].diff()
D_data.index = data.index
D_data.drop(D_data.index[0], inplace=True)  # 去除首行
D_data.plot()
plt.show()

# 协整检验
result = sm.tsa.stattools.coint(D_data["drs"], D_data["dr20"])
print(result)

order = 2

# 模型
model = VAR(D_data)
results = model.fit(order)
print(results.summary())
results.plot()
plt.show()

# 脉冲响应分析
irf = results.irf(10)
irf.plot(orth=False, impulse='drs')
irf.plot(orth=False, impulse='dr20')

# 累计脉冲响应
irf.plot_cum_effects(orth=False)
plt.show()

# 方差分解
fevd = results.fevd(5)
fevd.summary()
results.fevd(20).plot()
plt.show()
