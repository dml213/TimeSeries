import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.api import VAR
from statsmodels.tsa.vector_ar.vecm import VECM,select_order

# 读取数据
data = pd.read_excel('./interest_rates.xlsx', index_col=0)
#data.plot()

##15.2
# VAR model
print("order : ",select_order(data,5).summary())
model = VAR(data)
res = model.fit(3)
res.summary()

# VECM model
e_model = VECM(data)
e_res = e_model.fit()
print(e_res.summary())

##15.3
#预测
plt.plot(e_res.predict())
plt.ylabel('% p.a.')
plt.show()

#15.5
# LA-VAR causality test
granger_res = res.test_causality(1)
print(granger_res)

#15.6 Impuls设置有误
# Impulse Responses From the Interest Rate VECM
irf = res.irf(100)
irf.plot()