import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.filters.hp_filter import hpfilter

# 读取数据
data = pd.read_excel('./global_temps.xlsx',index_col=0,header=None)
data.index = pd.date_range('1850-01',periods=2016,freq='M')

cycle,trend = hpfilter(data,14400)
plt.plot(trend,label='14400',lw=1)
cycle,trend = hpfilter(data,129600)
plt.plot(trend,label='129600',ls=':',lw=1)
cycle,trend = hpfilter(data,500000)
plt.plot(trend,label='500000',ls='--',lw=2)
plt.legend()