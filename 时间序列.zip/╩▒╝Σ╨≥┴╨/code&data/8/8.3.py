import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.filters.hp_filter import hpfilter

# 读取数据
data = pd.read_excel('./gdp.xlsx',index_col=0,header=None)
print(data.index)

cycle,trend = hpfilter(data,10000)
plt.plot(trend,label='trend')
plt.plot(data,ls='--',lw=1,label='origin data')
plt.legend()