import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols

data=pd.read_csv("climate.csv",index_col=0)

def ARDL_fit(data,order,param):
    beta0=param[0]
    sigma=param[-1]
    alpha=np.sqrt(sigma)*np.random.randn(len(data))
    phi=[]
    for par in param[1:-1]:
        phi.append(par)
    
    fore=np.zeros(len(data))
    fore[:max(order)]=data.iloc[:max(order),0]
    
    for t in range(max(order),len(data)):
        fore[t]=beta0
        for j in range(len(order)):
            for i in range(order[j]+1):
                fore[t]+=phi[j][i]*data.iloc[t-i,j]
        fore[t]+=alpha[t]
    
    data['forecast']=fore
    plt.plot(data.iloc[:,0],'k',label='observation')
    plt.plot(data['forecast'],'r--',label='forecasting')
    plt.legend()
    return fore

# set order as example
order=(4,0,1,1,1)

# compute the lag data
data['temp_1']=np.zeros(len(data))
data['temp_1'][1:]=data['temp'][:-1]
data['temp_2']=np.zeros(len(data))
data['temp_2'][2:]=data['temp'][:-2]
data['temp_3']=np.zeros(len(data))
data['temp_3'][3:]=data['temp'][:-3]
data['temp_4']=np.zeros(len(data))
data['temp_4'][4:]=data['temp'][:-4]
data['volc_1']=np.zeros(len(data))
data['volc_1'][1:]=data['volc'][:-1]
data['soi_1']=np.zeros(len(data))
data['soi_1'][1:]=data['soi'][:-1]
data['amo_1']=np.zeros(len(data))
data['amo_1'][1:]=data['amo'][:-1]

# fit the model by OLS
lr = ols('temp ~ temp_1+temp_2+temp_3+temp_4+trf+volc+volc_1+soi+soi_1+amo+amo_1',data=data).fit()
print(lr.summary())

ARDL_fit(data,order,[-.2409,[0,.2769,.0334,.0163,.098],[.2511],[.0316,.051],[-.0271,-.0093],[.4116,-.1646],0.009])
