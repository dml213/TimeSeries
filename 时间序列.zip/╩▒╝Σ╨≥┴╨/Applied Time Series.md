[TOC]



# Chapter 3  


### ARMA Model
```python
import pandas as pd
import sys
import matplotlib.pyplot as plt
import statsmodels.api as sm
import statsmodels.tsa.api as smt
from statsmodels.tsa.stattools import adfuller as adf
from statsmodels.tsa.stattools import arma_order_select_ic
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.arima_model import ARMA
from statsmodels.graphics.api import qqplot
import numpy as np


def determinate_order(timeseries,maxlag):
    best_p = 0
    best_q = 0
    best_bic = sys.maxsize
    for p in np.arange(maxlag):
        for q in np.arange(maxlag):
            model = ARMA(timeseries, order=(p, q))
            try:
                results_ARMA = model.fit(disp=-1)
            except:
                continue
            bic = results_ARMA.bic
            if bic < best_bic:
                best_p = p
                best_q = q
                best_bic = bic
        # print('第{}次完成...'.format(p + 1))
    return best_p, best_q


def ARMA_model(train, order):
    arma_model = ARMA(train, order).fit(disp=-1)  # 激活模型
    plt.plot(arma_model.predict(), 'k', label="ARMA")
    plt.plot(train, 'r--', label="origin")
    plt.legend(loc=0, ncol=1)
    plt.show()
    print(arma_model.summary())
    print('RMSE: %.4f' % np.sqrt(sum((arma_model.predict() - train) ** 2) / train.size))   
    return arma_model
```


### EXAMPLE 3.1 An ARMA Process for the NAO

```python
import pandas as pd
import matplotlib.pyplot as plt
from ARMA import determinate_order, ARMA_model
import warnings

warnings.filterwarnings("ignore")

# read_data
data = pd.read_excel("dataset/nao.xlsx", index_col=0)

# plot
plt.show()

# determinate order
order = determinate_order(data["nao"], maxlag=5)

# model
ARMA_model = ARMA_model(data["nao"], order)

# predict
predict = ARMA_model.predict(start=0, end=830)
plt.plot(predict, 'g', label="predict")
plt.plot(data["nao"], 'r--', label="origin")
plt.legend(loc=0, ncol=1)
plt.show()
```
运行结果：
![3.1(1)](Time_Series_Photo/3.1(1).png)  


### EXAMPLE 3.2 Modeling the United Kingdom Interest Rate Spread

```python
import pandas as pd
import matplotlib.pyplot as plt
from ARMA import determinate_order, ARMA_model
import warnings

warnings.filterwarnings("ignore")

# read_data
data = pd.read_excel("dataset/interest_rates.xlsx", index_col=0)

# plot
plt.show()

# determinate order
order = determinate_order(data["spread"], maxlag=5)

# model
ARMA_model = ARMA_model(data["spread"], order)

# predict
predict = ARMA_model.predict(start=0, end=830)
plt.plot(predict, 'g', label="predict")
plt.plot(data["spread"], 'r--', label="origin")
plt.legend(loc=0, ncol=1)
plt.show()
```
运行结果：
![3.2](Time_Series_Photo/3.2.png)


### EXAMPLE 3.3 Modeling the Sunspot Number

```python
import pandas as pd
import matplotlib.pyplot as plt
from ARMA import determinate_order, ARMA_model
import warnings

warnings.filterwarnings("ignore")

# read_data
data = pd.read_excel("dataset/sunspots.xlsx", index_col=0)

# plot
plt.show()

# determinate order
order = determinate_order(data["sunspot"], maxlag=5)

# model
ARMA_model = ARMA_model(data["sunspot"], order)

# predict
predict = ARMA_model.predict(start=0, end=350)
predict.index = predict.index + 1700
plt.plot(predict, 'g', label="predict")
plt.plot(data, 'r--', label="origin")
plt.legend(loc=0, ncol=1)
plt.show()
```
运行结果：
![3.3](Time_Series_Photo/3.3.png)










# Chapter 4


### EXAMPLE 4.1 Modeling the United Kingdom Spread as an Integrated Process
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

# 读取数据
spread = pd.read_csv('interest_rates.csv',header=1,index_col=0)
dollar = pd.read_excel('dollar.xlsx',index_col=0)
#print(data.index)
date = pd.date_range('1952-03',periods=784,freq='M')
spread.index = date

print("Spread: statistic : ",adfuller(spread)[0],"   critical values:",adfuller(spread)[4])
print("Exchange: statistic : ",adfuller(dollar)[0],"   critical values:",adfuller(dollar)[4])
```
运行结果：
![4.1](Time_Series_Photo/4.1.png)







# Chapter 5


### Example 5.1 Unit Root Test on the Spread and the $-￡ Exange Rate
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

# 读取数据
spread = pd.read_csv('./interest_rates.csv',header=1,index_col=0)
dollar = pd.read_excel('./dollar.xlsx',index_col=0)
#print(data.index)
date = pd.date_range('1952-03',periods=784,freq='M')
spread.index = date

print("Spread: statistic : ",adfuller(spread)[0],"   critical values:",adfuller(spread)[4])
print("Exchange: statistic : ",adfuller(dollar)[0],"   critical values:",adfuller(dollar)[4])
```
运行结果
![5.1](Time_Series_Photo/5.1.png)


### Example 5.2 Is There a Unit Root in Global Temperatures?
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

# 读取数据
data = pd.read_excel('./global_temps.xlsx',index_col=0)
#print(data.index)
date = pd.date_range('1850-02',periods=2015,freq='M')
data.index = date
data.plot()
print("tau statistic : ",adfuller(data)[0],"   critical values:",adfuller(data)[4])
```
运行结果：
![5.2(1)](Time_Series_Photo/5.2(1).png)
![5.2(2)](Time_Series_Photo/5.2(2).png)


### Example 5.3 Trends in Wine and Spirit Consumption
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

# 读取数据
data = pd.read_excel('./wine_spirits.xlsx',index_col=0,header=None)
data.plot()

# we include the trend to excetu the ADF test
print("tau statistic : ",adfuller(data,regression='ct')[0],"   critical values:",adfuller(data,regression='ct')[4])
```
运行结果：
![5.3(1)](Time_Series_Photo/5.3(1).png)
![5.3(2)](Time_Series_Photo/5.3(2).png)










# Chapter 6


### EXAMPLE 6.1 The Great Crash, the Oil Price Shock, and ADF Tests of Breaking Trend Processes
```python
import pandas as pd
from statsmodels.tsa import stattools

data=pd.read_excel('gdp.xlsx',index_col=0)


def ADF_test(df,name):
    df['diff']=df[name].copy()
    
    for i in range(100):
        results=stattools.adfuller(data['diff'][i:])
        if(results[0]<results[4]['1%']):
            print("the series are I(",str(i),")!:)")
            df['diff'].plot()
            break
        else:
            print("the series are not I(",str(i),")!:(")
        df['diff']=df['diff'].diff(1)
        
    return i

ADF_test(data,'gdp')
```
运行结果：
![6.1(1)](Time_Series_Photo/6.1(1).png)
![6.1(2)](Time_Series_Photo/6.1(2).png)


### EXAMPLE 6.3 LSTR and Fourier Models for United States Stock Prices
```python
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as sm

data=pd.read_excel('gdp.xlsx',use_col=[1])

def S_t(t,gamma,m,T=50):
    return pow((1+math.exp(-gamma*(t-m*T))),-1)

def estim(y,param):
    n=len(y)
    T=n/2
    gamma,m=param[0],param[1]
    
    data['t']=np.zeros(n)
    data['st']=np.zeros(n)
    for t in range(n):
        data.loc[t,('t')]=t
        data.loc[t,('st')]=S_t(t,gamma,m,T)
    
    results = sm.ols(formula='gdp ~ t + st + t*st', data = data).fit()
    data['residual'] = data['gdp']-data['t']*results.params[1]-data['st']*results.params[2]\
                    -data['t']*data['st']*results.params[3]-results.params[0]
    return results

y=data['gdp']
results=estim(data['gdp'],[0.0085,1.907])
print(results.summary())

fore=np.zeros(len(y))
fore=results.params[0]+results.params[1]*data['t']+results.params[2]*data['st']\
    +results.params[3]*data['t']*data['st']

plt.plot(fore)
plt.plot(data['gdp'])
```
运行结果：
![6.3](Time_Series_Photo/6.3.png)



### EXAMPLE 6.5 Determining a Fourier approximation for United States Stock Prices
```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as sm

data=pd.read_excel('gdp.xlsx',index_col=0)

w=0.001
data['x']=np.arange(len(data))
x=data['x'].values
data['cwx']=np.cos(w*x)
data['c2wx']=np.cos(2*w*x)
data['c3wx']=np.cos(3*w*x)
data['swx']=np.sin(w*x)
data['s2wx']=np.sin(2*w*x)
data['s3wx']=np.sin(3*w*x)

results=sm.ols(formula='gdp ~ cwx + c2wx + c3wx + swx + s2wx + s3wx', data = data).fit()
print(results.summary())

fore=np.zeros(len(data))
fore=results.params[0]+results.params[1]*data['cwx']+results.params[2]*data['c2wx']\
    +results.params[3]*data['c3wx']+results.params[4]*data['swx']\
    +results.params[5]*data['s2wx']+results.params[6]*data['s3wx']

plt.plot(data['gdp'])
plt.plot(fore)
plt.legend(['observed','forecast'])
```
运行结果：
![6.5](Time_Series_Photo/6.5.png)










# Chapter 8


### EXAMPLE 8.2 Fitting HP Trends to Global Temperatures
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.filters.hp_filter import hpfilter

# 读取数据
data = pd.read_excel('./global_temps.xlsx',index_col=0,header=None)
data.index = pd.date_range('1850-01',periods=2016,freq='M')

cycle,trend = hpfilter(data,14400)
plt.plot(trend,label='14400',lw=1)
cycle,trend = hpfilter(data,129600)
plt.plot(trend,label='129600',ls=':',lw=1)
cycle,trend = hpfilter(data,500000)
plt.plot(trend,label='500000',ls='--',lw=2)
plt.legend()
```
运行结果：
![8.2](Time_Series_Photo/8.2.png)


### EXAMPLE 8.3 Fitting an HP Trend to British Real Per Capita GDP
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.filters.hp_filter import hpfilter

# 读取数据
data = pd.read_excel('./gdp.xlsx',index_col=0,header=None)
print(data.index)

cycle,trend = hpfilter(data,10000)
plt.plot(trend,label='trend')
plt.plot(data,ls='--',lw=1,label='origin data')
plt.legend()
```
运行结果：
![8.3](Time_Series_Photo/8.3.png)










# Chapter 9


### Example 9.1  A Deterministic Seasonal Model for Rainfall  
```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols

# 读取数据
data = pd.read_excel('dataset/rainfall.xlsx', index_col=None)
rainfall = pd.DataFrame(np.sqrt(data["rainfall"]))

# 分离出月份列
date = data["date"].str.split('M', expand=True)
month = date[1]
month = pd.cut(month.astype(str).astype(int),12,labels=range(1,13))
data[1] = month

# 将月份转换为哑变量
month = pd.get_dummies(data[1], prefix="month")
data = month.join(rainfall)
print(data)

# OLS拟合
model = ols('rainfall ~ month_1+month_2+month_3+month_4+month_5+month_6'
         '+month_7+month_8+month_9+month_10+month_11+month_12 -1', data=data).fit(fit_intercept=False)
print(model.summary())

# 月降水量估计值
rainfall_estimate = round(model.params ** 2 * 10)
print(rainfall_estimate)  
```
运行结果：
![9.1](Time_Series_Photo/9.1.png)


### Example 9.3    Global Temperatures Using Exponential Smoothing
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import warnings

warnings.filterwarnings("ignore")
data = pd.read_excel('dataset/global_temps.xlsx', index_col=0)

model = ExponentialSmoothing(data, seasonal='additive', seasonal_periods=12).fit()
pred = model.predict(start=data.index[0], end=data.index[-1])

# plot
plt.plot(data, 'r--', label="origin")
plt.plot(pred, 'b', label="predict")
plt.legend()
plt.show()
```
运行结果：
![9.3](Time_Series_Photo/9.3.png)










# Chapter 11


### EXAMPLE 11.4 A Markov-Switching Model for the dollar-pounds Exchange Rate
```python
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller,kpss
from statsmodels.tsa.arima_model import ARMA
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.linear_model import LinearRegression
from scipy.optimize import leastsq,minimize


# read data
data = pd.read_excel('./data/dollar.xlsx',index_col=0)[-900:]
diff = data.diff().dropna()
plt.figure(figsize=(16,8))
plt.plot(data)
plt.title('dollar-pounds exchange rate')
plt.show()

# fit model
model = sm.tsa.MarkovRegression(data, k_regimes=2)
res = model.fit()
res.summary()
```
运行结果：
![11.4](Time_Series_Photo/11.4.png)


### EXAMPLE 11.5 Nonlinearity Tests for Long Interest Rate
```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import bds


# read data
data = pd.read_excel('./data/interest_rates.xlsx',index_col=0)['r20']
plt.figure(figsize=(16,8))
plt.plot(data)
plt.title('Long Interest Rate')
plt.show()

# BDS test
bds_statis = bds(data)
print('bds test : ',bds_statis)
```
运行结果：
![11.5](Time_Series_Photo/11.5.png)










# Chapter12


### EXAMPLE 12.1 An ARDL Model for UK Interest Rates
```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols

data=pd.read_csv("climate.csv",index_col=0)

def ARDL_fit(data,order,param):
    beta0=param[0]
    sigma=param[-1]
    alpha=np.sqrt(sigma)*np.random.randn(len(data))
    phi=[]
    for par in param[1:-1]:
        phi.append(par)
    
    fore=np.zeros(len(data))
    fore[:max(order)]=data.iloc[:max(order),0]
    
    for t in range(max(order),len(data)):
        fore[t]=beta0
        for j in range(len(order)):
            for i in range(order[j]+1):
                fore[t]+=phi[j][i]*data.iloc[t-i,j]
        fore[t]+=alpha[t]
    
    data['forecast']=fore
    plt.plot(data.iloc[:,0],'k',label='observation')
    plt.plot(data['forecast'],'r--',label='forecasting')
    plt.legend()
    return fore

# set order as example
order=(4,0,1,1,1)

# compute the lag data
data['temp_1']=np.zeros(len(data))
data['temp_1'][1:]=data['temp'][:-1]
data['temp_2']=np.zeros(len(data))
data['temp_2'][2:]=data['temp'][:-2]
data['temp_3']=np.zeros(len(data))
data['temp_3'][3:]=data['temp'][:-3]
data['temp_4']=np.zeros(len(data))
data['temp_4'][4:]=data['temp'][:-4]
data['volc_1']=np.zeros(len(data))
data['volc_1'][1:]=data['volc'][:-1]
data['soi_1']=np.zeros(len(data))
data['soi_1'][1:]=data['soi'][:-1]
data['amo_1']=np.zeros(len(data))
data['amo_1'][1:]=data['amo'][:-1]

# fit the model by OLS
lr = ols('temp ~ temp_1+temp_2+temp_3+temp_4+trf+volc+volc_1+soi+soi_1+amo+amo_1',data=data).fit()
print(lr.summary())

ARDL_fit(data,order,[-.2409,[0,.2769,.0334,.0163,.098],[.2511],[.0316,.051],[-.0271,-.0093],[.4116,-.1646],0.009])
```
运行结果：
![12.1](Time_Series_Photo/12.1.png)










# Chapter 13


### EXAMPLE 13.1 The Interaction of the United Kingdom Bond and Gilt Markets
### EXAMPLE 13.2 Variance Decomposition and Innovation Accounting for the Bond and Gilt Markets
```python
import pandas as pd
import warnings
from statsmodels.tsa.api import VAR
import matplotlib.pyplot as plt
import statsmodels.api as sm

warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["SimHei"]   # 用来正常显示中文标签
plt.rcParams["axes.unicode_minus"] = False     # 用来正常显示负号

# 读取数据
data = pd.read_excel('interest_rates.xlsx', index_col=0)

# 差分
D_data = pd.DataFrame()
D_data["drs"] = data["rs"].diff()
D_data["dr20"] = data["r20"].diff()
D_data.index = data.index
D_data.drop(D_data.index[0], inplace=True)  # 去除首行
D_data.plot()
plt.show()

# 协整检验
result = sm.tsa.stattools.coint(D_data["drs"], D_data["dr20"])
print(result)

order = 2

# 模型
model = VAR(D_data)
results = model.fit(order)
print(results.summary())
results.plot()
plt.show()

# 脉冲响应分析
irf = results.irf(10)
irf.plot(orth=False, impulse='drs')
irf.plot(orth=False, impulse='dr20')

# 累计脉冲响应
irf.plot_cum_effects(orth=False)
plt.show()

# 方差分解
fevd = results.fevd(5)
fevd.summary()
results.fevd(20).plot()
plt.show()
```
运行结果：
![13.1](Time_Series_Photo/13.1.png)
![13.2](Time_Series_Photo/13.2.png)


### EXAMPLE 13.3 Quenouille’s Hog Series Example Revisited
```python
import pandas as pd
import numpy as np
import warnings
from statsmodels.tsa.api import VAR, SVAR
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["SimHei"]   # 用来正常显示中文标签
plt.rcParams["axes.unicode_minus"] = False     # 用来正常显示负号

# 读取数据
data = pd.read_excel('quenouille.xlsx', index_col=0)
# data.plot()
# plt.show()

# VAR模型
model = VAR(data)
results = model.fit(4)
print(results.summary())

# 残差自相关图
results.plot_acorr(6)
plt.show()

# 脉冲响应分析
irf = results.irf(10)
irf.plot(orth=False, impulse='y1')
irf.plot(orth=False, impulse='y2')
irf.plot(orth=False, impulse='y3')
irf.plot(orth=False, impulse='y4')
irf.plot(orth=False, impulse='y5')
plt.show()

# 累计脉冲响应
irf.plot_cum_effects(orth=False)
plt.show()

# 方差分解
fevd = results.fevd(5)
fevd.summary()
results.fevd(20).plot()
plt.show()


# SVAR模型
model = SVAR(data, svar_type="A",                      # A:待估计矩阵
             A=np.array([[1, 0, 0, 0, 0],
                         ['E', 1, 0, 0, 0],
                         [0, 0, 1, 0, 0],
                         [0, 0, 'E', 1, 0],
                         [0, 'E', 'E', 0, 1]]))
results = model.fit()
print(results.summary())
print("矩阵A估计为：\n", results.A)

# 累计脉冲响应
irf = results.irf(10)
irf.plot_cum_effects(orth=False)
plt.show()
```
运行结果：
![13.3(4)](Time_Series_Photo/13.3(4).png)
![13.3(1)](Time_Series_Photo/13.3(1).png)
![13.3(2)](Time_Series_Photo/13.3(2).png)
![13.3(3)](Time_Series_Photo/13.3(3).png)










# Chapter 14


### EXAMPLE 14.1 Are United Kingdom Interest Rates Cointegrated?
### EXAMPLE 14.2 Estimating a Cointegrating Relationship Between United Kingdom Interest Rates
```python
import pandas as pd
from statsmodels.tsa import stattools
import statsmodels.formula.api as sm


data=pd.read_excel('interest_rates.xlsx',index_col=0)

data['rs_diff1']=data['rs'].diff(1)
data['r20_diff1']=data['r20'].diff(1)

data.plot()

# test if both R20 and RS are really I(1) processes
print("ADF test of RS:\n",stattools.adfuller(data['rs']))
print("\nADF test of R20:\n",stattools.adfuller(data['r20']))
print("\nADF test of RS_diff1:\n",stattools.adfuller(data['rs_diff1'][1:]))
print("\nADF test of R20_diff1:\n",stattools.adfuller(data['r20_diff1'][1:]))
# it shows both R20 and RS are indeed I(1) processes

# test cointegration by EG-test
results=stattools.coint(data['rs'],data['r20'])
print("\n\ntest cointegration by EG-test:",results)
print("************************")
if(results[0]<results[2][1]):
    print("the two series are cointegrated:)")
else:
    print("the two series are not cointegrated:(")
print("************************")


# estimate the Cointegrating Relationship by OLS
# RS~R20
results = sm.ols(formula='rs ~ r20',data = data).fit()
print("\n\nparameters of RS~R20:\n",results.params)
data['residual_rs'] = data['rs'] - data['r20'] * results.params[1] - results.params[0]

# R20~RS
results = sm.ols(formula='r20 ~ rs',data = data).fit()
print("\n\nparameters of R20~RS:\n",results.params)
data['residual_r20'] = data['r20'] - data['rs'] * results.params[1] - results.params[0]
```
运行结果：
![14.1](Time_Series_Photo/14.1.png)
![14.2](Time_Series_Photo/14.2.png)


### EXAMPLE 14.3 Error Correction Modeling of Global Temperatures
```python
import pandas as pd
from statsmodels.tsa import stattools
import statsmodels.formula.api as sm

data=pd.read_csv("climate.csv",index_col=0)


data['temp_diff1']=data['temp'].diff(1)
data['trf_diff1']=data['trf'].diff(1)
data['trf_diff2']=data['trf_diff1'].diff(1)

data[['temp_diff1','trf_diff1','trf_diff2']].plot()


# test if both temp and trf are I(1) processes
# while others are I(0) processes
print("ADF test of temp:\n",stattools.adfuller(data['temp']))
print("\nADF test of temp_diff1:\n",stattools.adfuller(data['temp_diff1'][1:]))
print("\nADF test of trf:\n",stattools.adfuller(data['trf']))
print("\nADF test of trf_diff1:\n",stattools.adfuller(data['trf_diff1'][1:]))
print("\nADF test of trf_diff2:\n",stattools.adfuller(data['trf_diff2'][2:]))
print("\nADF test of volc:\n",stattools.adfuller(data['volc']))
print("\nADF test of soi:\n",stattools.adfuller(data['soi']))
print("\nADF test of amo:\n",stattools.adfuller(data['amo']))
# we can see TRF is I(2) actually


# test cointegration by EG-test
results=stattools.coint(data['temp'],data[['trf','volc','soi','amo']])
print("\n\ntest cointegration by EG-test:",results)
print("************************")
if(results[0]<results[2][1]):
    print("the two series are cointegrated:)")
else:
    print("the two series are not cointegrated:(")
print("************************")


# estimate the ECM
results = sm.ols(formula='temp ~ trf + volc + soi + amo', data = data).fit()
print(results.summary())
print("\n\nparameters:\n",results.params)
data['residual'] = data['temp']-data['trf']*results.params[1]\
                -data['volc']*results.params[2]-data['soi']*results.params[3]\
                -data['amo']*results.params[4]-results.params[0]

ECM = sm.ols(formula='temp ~ trf + volc + soi + amo + residual',data = data).fit()
print(ECM.summary())
print("\n\nparameters of ECM:\n",ECM.params)
```
运行结果：
![14.3(1)](Time_Series_Photo/14.3(1).png)
![14.3(2)](Time_Series_Photo/14.3(2).png)










# Chapter 15


### EXAMPLE 15.2 A VECM Representation of United Kingdom Long and Short Interest Rates
```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.api import VAR
from statsmodels.tsa.vector_ar.vecm import VECM,select_order

# 读取数据
data = pd.read_excel('./interest_rates.xlsx', index_col=0)
#data.plot()

##15.2
# VAR model
print("order : ",select_order(data,5).summary())
model = VAR(data)
res = model.fit(3)
res.summary()

# VECM model
e_model = VECM(data)
e_res = e_model.fit()
print(e_res.summary())

##15.3
#预测
plt.plot(e_res.predict())
plt.ylabel('% p.a.')
plt.show()

#15.5
# LA-VAR causality test
granger_res = res.test_causality(1)
print(granger_res)

#15.6 Impuls设置有误
# Impulse Responses From the Interest Rate VECM
irf = res.irf(100)
irf.plot()
```
运行结果：
![15.2(1)](Time_Series_Photo/15.2(1).png)
![15.2(2)](Time_Series_Photo/15.2(2).png)
![15.2(3)](Time_Series_Photo/15.2(3).png)






















