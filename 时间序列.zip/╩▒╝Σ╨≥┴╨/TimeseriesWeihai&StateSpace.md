# pdf作业

## 向量矩阵

### 代码

```python
import numpy as np
import math

# Vectors Matrix and other stuff
# Create a vector
print(np.array([2,6,1,3,11]))
print(np.arange(-4,5,1.5))
print(np.arange(-4,5))
print(np.linspace(4,5,5))
print(np.linspace(2,2,5))
# Create a matrix
print(np.linspace(4,4,9).reshape(3,3))
print(np.array([11,5,9,2]).reshape(2,2))
# 切片和索引
x=np.array([[21,-3,102],[5,-6,10],[2,1,-13],[15,-7,4]])
print(x)                                                   #打印矩阵
print(x[1,0])                                              #寻找第4个元素5
print(x[[0,1,2],[0,1,2]])                                  #打印三个位置的元素21，-6，-13
print(x[(x>2)&(x<12)])                                     #打印2到12的数
print(x[2:4,0:2])                                          #取2，1，15，-7构成的2维矩阵
# removing elements
a=np.array([4,22,56,77,26,88,100])
index=[2,4,5]
b=np.delete(a,index)
print(b)                                                    #删除第3，5，6个元素
print(np.delete(x,[1],1))  
```

### 运行截图

![](Weihai_Photo\QQ截图20200815222316.png)

## 函数与例子

### 代码

```python
# Create function
# Excerise_calculate_variance
def var(x):                                                  #方差
    c=np.mean((x-x.mean())**2)
    return c
# Calculate covariance
def cov(x,y):                                                #协方差
    return np.mean((x-np.mean(x))*(y-np.mean(y)))
# Calculate correlation
def cor(x,y):                                                 #相关系数
    return cov(x,y)/math.sqrt(var(x)*var(y))
x=np.arange(1,5)
y=np.arange(2,6)
print(var(x))
print(var(y))
print(cov(x,y))
print(cor(x,y))

# Exercise1
a=np.arange(21,121)
print(a)
b=len(a)
print(b)
d=a[4]
print(d)
f=a[1:6]
print(f)
g=[a[0],a[2],a[6]]
print(g)
h=np.arange(21,101,4)
print(h)
i=a[(a>=24)&(a<=29)]
print(i)
a=np.arange(21,121).reshape(25,4)
print(a)
m=a[0:25,1]
print(m)
n=a[0:5,2]
print(n)
o=a[5:12,1:3]
print(o)

# Exercise2
#（1）
v=np.arange(3,38)
print(v)
#（2）创建0向量
z=np.zeros(len(v))
print(z)
#（3）变换元素
for i in v:
    if i<14:
        z[i-3]=1
    elif i>14 and i<26:
        z[i-3]=2
    else:
        z[i-3]=3
print(z)
#（4）随机数向量
data1=np.random.randint(1,11,(1,10))
print(data1)
#（5）随机数矩阵
data2=np.random.randint(1,21,(3,20))
print(data2)
#(6) 相关矩阵
c=np.zeros([3,3])
print(c)

# Exercise3
# 年龄组
agegroup=np.array([43,26,29,29,65,65])
agegroup_new=np.zeros(6)
for i in range(0,6):
    if agegroup[i]<=35:
        agegroup_new[i]=1
    elif agegroup[i]>35 and agegroup[i]<55:
        agegroup_new[i]=2
    else:
        agegroup_new[i]=3
print(agegroup_new)
# 工资组
wage=np.array([4044,2303,2612,2757,4988,3312])
wage1=np.zeros(6)
for i in range(0,6):
    if wage[i]<2500:
        wage1[i]=1
    elif wage[i]>2500 and wage[i]<3500:
        wage1[i]=2
    elif wage[i]>3500 and wage[i]<4500:
        wage1[i]=3
    else:
        wage1[i]=4
print(wage1)
# 比较
sex=np.array([1,0,1,0,1,1])
one = 0
two = 0
three = 0
four = 0
one1 = 0
two1 = 0
three1 = 0
four1 = 0
for i in range(0,6):
    if sex[i]==1:
        if wage1[i]==3:
            three+=1
        elif wage1[i]==1:
            one+=1
        elif wage1[i]==2:
            two+=1
        else:
            four+=1
    if sex[i]==0:
        if wage1[i]==3:
            three1+=1
        elif wage1[i]==1:
            one1+=1
        elif wage1[i]==2:
            two1+=1
        else:
            four1+=1
print("male have "+str(one)+"<2500 ,"+str(two)+" between 2500 and 3500 ,"+str(three)+" between 3500 and 4500 ,"+str(four)+">4500")
print("female have "+str(one1)+"<2500 ,"+str(two1)+" between 2500 and 3500 ,"+str(three1)+" between 3500 and 4500 ,"+str(four1)+">4500")
```

### 运行截图![QQ截图20200815222908](Weihai_Photo\QQ截图20200815222908.png)

![](Weihai_Photo\QQ截图20200815222943.png)

![](Weihai_Photo\QQ截图20200815222957.png)

## 可视化

### 代码

```python
# Data visualization
# first plot
from matplotlib import pyplot as plt
import random
x=np.arange(1,7)
y=2*x+5
plt.title("first plot")
plt.xlabel("My x label")
plt.ylabel("My y label")
plt.plot(x,y,'y')
plt.show()
# scatter plot
x=np.random.randint(160,180,50)
y=x/3+np.random.uniform(1,10)
plt.title("scatter")
plt.xlabel("My x label")
plt.ylabel("My y label")
area=np.pi*4**2
plt.scatter(x,y,s=area,c="r",alpha=0.4,label="A")
plt.legend()
plt.show()
# bar plot
x=[5,8,10,6,9,11]
y=[12,16,6,6,15,7]
plt.bar(x,y,align='center',color='r')
plt.xlabel("My x label" )
plt.ylabel("My y label")
plt.title('my first barplot')
plt.show()
# example cheese
x=np.random.randint(1,4,300)
y=np.zeros(300)
z=np.zeros(300)
y1=[]
z1=[]
y2=[]
z2=[]
y3=[]
z3=[]
for i in range(0,300):
    if x[i]==1:
        y[i]=random.uniform(1,4)
        z[i]=random.randint(50,60)
        y1.append(y[i])
        z1.append(z[i])
    if x[i]==2:
        y[i]=random.uniform(3,7)
        z[i]=random.randint(30,50)
        y2.append(y[i])
        z2.append(z[i])
    if x[i]==3:
        y[i]=random.uniform(6,10)
        z[i]=random.randint(60,80)
        y3.append(y[i])
        z3.append(z[i])
area=np.pi*4**2
plt.title("cheese")
plt.xlabel("age")
plt.ylabel("appreciate")
plt.scatter(z1,y1,s=area,c="r",alpha=0.4,label='no wine')
plt.scatter(z2,y2,s=area,c="g",alpha=0.4,label='red wine')
plt.scatter(z3,y3,s=area,c="y",alpha=0.4,label='white wine')
plt.legend()
plt.show()
# pie
labels=['Wed','Tue','Mon','fri','Thu']
sizes=[26,13,4,39,17]
colors=['b','r','g','pink','y']
fig=plt.figure()
plt.pie(sizes,labels=labels,colors=colors,autopct='%1.1f%%',pctdistance=0.8,shadow=True)
plt.show()
# example
sexmat=np.random.randint(0,2,200)
edu=np.zeros(200)
job=np.zeros(200)
wage=np.zeros(200)
for i in range(0,200):
    if sexmat[i]==1:
        edu[i]=np.random.uniform(2,3.6)
        job[i]=np.random.uniform(1.2,4)
        wage[i]=-2.3+5*np.random.random()
    else:
        edu[i] = np.random.uniform(1, 3.6)
        job[i] = np.random.uniform(1, 2.8)
        wage[i] = -2 +3* np.random.random()
plt.scatter(sexmat,edu,s=area,c="r",alpha=0.4,label='edu')
plt.scatter(sexmat,job,s=area,c="g",alpha=0.4,label='job')
plt.scatter(sexmat,wage,s=area,c="y",alpha=0.4,label='wage')
plt.legend()
plt.show()
```

### 运行截图

![](Weihai_Photo\1.png)

![](Weihai_Photo\2.png)

![](Weihai_Photo\3.png)

![wine](Weihai_Photo\4.png)

![](Weihai_Photo\5.png)

## Simple linear regression model

### 代码

```python
# Simple linear regression model
# first example
from scipy import stats
x1=np.random.uniform(0,20,40)
y1=stats.chi2.pdf(x1,df=6)
e=np.random.normal(0,1,40)
z1=1.3+8*y1+e
plt.scatter(x1,z1)
plt.legend()
x=np.arange(0,20)
y=1.3+0.8*x
plt.title("what is the relation between x and y")
plt.xlabel("X")
plt.ylabel("Y")
plt.plot(x,y,"y")
plt.show()
# temperature and appreciation
gender=1.1*np.random.random(200)
tem=2+np.arange(0,9.99,0.05)
ef=0.4*np.random.randn(200)
em=0.8*np.random.randn(200)
apr=np.zeros(200)
for i in range(0,200):
    if gender[i]==0:
        apr[i]=7-0.3*tem[i]+ef[i]
    else:
        apr[i]=10-0.7*tem[i]+em[i]
plt.title(" temperature and appreciation picture 1")
plt.xlabel("temperature")
plt.ylabel("appreciation")
plt.scatter(tem,apr,s=area,c="r",alpha=0.4)
plt.legend()
plt.show()
```

### 运行截图

![](Weihai_Photo\7.png)

![](Weihai_Photo\8.png)

## 优化

### 代码

```python
 Optim_ization with R
# first
from scipy import optimize
x=np.random.uniform(1,8,100)
y=1*np.random.randn(100)+0.8*x
plt.scatter(x,y)
plt.legend()
plt.show()
e=np.zeros(100)
def function(beta):
    b=beta
    for i in range(0,99):
        e[i]=(y[i]-b*x[i])**2
    return np.sum(e)
optimize.fmin_bfgs(function,0)
# second
x=np.sin(np.arange(0.01,1.01,0.01))
b=np.random.random(1)
y=-b*x+0.03*np.random.randn(len(x))
plt.scatter(x,y)
plt.legend()
plt.show()
h=np.zeros(100)
def f(beta):
    n=beta
    for i in range(0,100):
        h[i]=np.fabs(y[i]-n*x[i])
    return np.sum(h)
optimize.fmin_bfgs(f,0)
# third
def f(a):
    x=a[0]
    y=a[1]
    return ((x-2)**2+(4+y)**2)
x0=[0,0]
myresults=optimize.minimize(f,x0)
print(myresults)
# forth
from mpl_toolkits.mplot3d import Axes3D
fig=plt.figure()
ax3=Axes3D(fig)
x=np.linspace(-5,10,50)
y=np.linspace(-11,2,50)
X,Y=np.meshgrid(x,y)
Z=((-2+X)**2+(4+Y)**2)
ax3.plot_surface(X,Y,Z,cmap='rainbow')
plt.show()

# The normal distribution
x=np.linspace(-3.8,4.2,800)
mu=0.2
sigma=math.sqrt(1.5)
print(sigma)
pdf=np.zeros(800)
cdf=np.zeros(800)
for i in range(0,len(x)):
   pdf[i]=(1/(math.sqrt(2*math.pi*sigma**2)))*math.exp(-0.5*((x[i]-mu)**2/sigma**2))
   cdf[i]=np.sum(pdf[0:i]/100)
plt.plot(pdf)
plt.show()
plt.plot(cdf)
plt.show()

# Bivariate normal distribution
A=np.array([1.0,0.7,0.7,1.4]).reshape(2,2)
InvA=np.linspace((1/(A[0,0]*A[1,1]-A[0,1]**2)),(1/(A[0,0]*A[1,1]-A[0,1]**2)),4).reshape(2,2)
InvA[0,0]=InvA[0,0]*A[1,1]
InvA[1,1]=InvA[1,1]*A[0,0]
InvA[1,0]=InvA[1,0]*-A[0,1]
InvA[0,1]=InvA[1,0]*-A[0,1]
B=np.diag((1,1))
B[1,0]=-A[0,1]/A[1,1]
C=np.diag((1,2))
C[0,0]=1/(A[0,0]-A[0,1]**2/A[1,1])
C[1,1]=1/A[1,1]
mx=np.zeros(100)
my=np.zeros(100)
vx=0.5
vy=0.6
covxy=-0.3
sigma=np.zeros(4).reshape(2,2)
sigma[0,0]=vx
sigma[1,1]=vy
sigma[0,1]=sigma[1,0]=covxy
x=np.linspace(-4,4,100)
y=np.linspace(-4,4,100)
X,Y=np.meshgrid(x,y)
Z=(1/(2*math.pi*np.linalg.det(sigma)**0.5))*np.exp(-0.5*((vy*(X-mx)**2+(Y-my)*(-2*(X-mx)*covxy+vx*(Y-my)))/(vx*vy-2*covxy)))
fig=plt.figure()
ax4=Axes3D(fig)
ax4.plot_surface(X,Y,Z,cmap='rainbow')
plt.show()
```

### 运行截图

![](Weihai_Photo\10.png)

![](Weihai_Photo\13.png)

![](Weihai_Photo\14.png)

![](Weihai_Photo\15.png)

![](Weihai_Photo\16.png)

![](Weihai_Photo\18.png)

## state space

### 代码

```python
 State-Space
e=math.sqrt(0.8)*np.random.randn(100)
u=math.sqrt(0.4)*np.random.randn(100)
y=np.zeros(100)
alpha=np.zeros(100)
y[0]=e[0]
alpha[0]=u[0]
for i in range(1,100):
    y[i]=alpha[i-1]+e[i]
    alpha[i]=0.9*alpha[i-1]+u[i]
plt.plot(alpha)
plt.plot(y,'.')
plt.show()
# Concentrated Likelihood
n=100
su=0.1
se=0.4
qreal=su/se
e=math.sqrt(se)*np.random.randn(n)
u=math.sqrt(su)*np.random.randn(n)
z=1;wreal=0.97
y=np.zeros(n)
alpha=np.zeros(n)
y[0]=e[0];alpha[0]=u[0]
for i in range(1,100):
    y[i]=z*alpha[i-1]+e[i]
    alpha[i]=wreal*alpha[i-1]+u[i]
'''standard kalman filter approach'''
a=np.zeros(100)
p=np.zeros(100)
a[0]=0;p[0]=10
k=np.zeros(100)
v=np.zeros(100)
def f(mypa):
    w=np.fabs(mypa[0])
    q=np.fabs(mypa[1])
    z=1
    likelihood=0
    sigmae=0
    for i in range(1, 100):
        k[i] = (z * w * p[i - 1]) / ((z ** 2) * p[i - 1] + 1)
        p[i] = (w ** 2) * p[i - 1] - w * z * k[i] * p[i - 1] + q
        v[i] = y[i] - z * a[i - 1]
        a[i] = w * a[i - 1] + k[i] * v[i]
        sigmae = sigmae + ((v[i] ** 2) / ((z ** 2) * p[i - 1] + 1))
        likelihood = likelihood + 0.5 * math.log(2 * math.pi) + 0.5 + 0.5 * math.log((z ** 2) * p[i - 1] + 1)
    return (likelihood+0.5*n*math.log(sigmae/n))
x0=[0.85,0.5]
myresults=optimize.minimize(f,x0)
print(myresults)
# The local level model
e=math.sqrt(0.5)*np.random.randn(100)
u=math.sqrt(0.2)*np.random.randn(100)
y=np.zeros(100)
alpha=np.zeros(100)
y[0]=e[0]
alpha[0]=u[0]
for i in range(1,100):
    y[i]=alpha[i-1]+e[i]
    alpha[i]=alpha[i-1]+u[i]
'''standard kalman filter approach'''
a=np.zeros(100)
p=np.zeros(100)
a[0]=0;p[0]=10000
k=np.zeros(100)
v=np.zeros(100)
def f(mypa):
    q=np.fabs(mypa)
    w=1
    z=1
    likelihood=0
    sigmae=0
    for i in range(1, 100):
        k[i] = (z * w * p[i - 1]) / ((z ** 2) * p[i - 1] + 1)
        p[i] = (w ** 2) * p[i - 1] - w * z * k[i] * p[i - 1] + q
        v[i] = y[i] - z * a[i - 1]
        a[i] = w * a[i - 1] + k[i] * v[i]
        sigmae = sigmae + ((v[i] ** 2) / ((z ** 2) * p[i - 1] + 1))
        likelihood = likelihood + 0.5 * math.log(2 * math.pi) + 0.5 + 0.5 * math.log((z ** 2) * p[i - 1] + 1)
    return (likelihood+0.5*n*math.log(sigmae/n))
results=optimize.minimize(f,[0.2])
print(results)
# The local level with drift
e=math.sqrt(0.8)*np.random.randn(100)
u=math.sqrt(0.1)*np.random.randn(100)
y=np.zeros(100)
alpha=np.zeros(100)
co=0.1
y[0]=e[0]
alpha[0]=u[0]
for i in range(1,100):
    y[i]=alpha[i-1]+e[i]
    alpha[i]=co+alpha[i-1]+u[i]
'''standard kalman filter approach'''
a=np.zeros(100)
p=np.zeros(100)
a[0]=0;p[0]=10000
k=np.zeros(100)
v=np.zeros(100)
v[0]=0
def f(mypa):
    q=np.fabs(mypa[0])
    co=np.fabs(mypa[1])
    w=1
    z=1
    likelihood=0
    sigmae=0
    for i in range(1, 100):
        k[i] = (z * w * p[i - 1]) / ((z ** 2) * p[i - 1] + 1)
        p[i] = (w ** 2) * p[i - 1] - w * z * k[i] * p[i - 1] + q
        v[i] = y[i] - z * a[i - 1]
        a[i] = co+w * a[i - 1] + k[i] * v[i]
        sigmae = sigmae + ((v[i] ** 2) / ((z ** 2) * p[i - 1] + 1))
        likelihood = likelihood + 0.5 * math.log(2 * math.pi) + 0.5 + 0.5 * math.log((z ** 2) * p[i - 1] + 1)
    return (likelihood+0.5*n*math.log(sigmae/n))
x0=[0.6,0.2]
results=optimize.minimize(f,x0)
print(results)
# Common Function
def generate(n,sigmae,sigmau,co):
    e = math.sqrt(sigmae) * np.random.randn(n)
    u = math.sqrt(sigmau) * np.random.randn(n)
    y = np.zeros(n)
    alpha = np.zeros(n)
    y[0] = e[0]
    alpha[0] = u[0]
    for i in range(1, 100):
        alpha[i] = co + alpha[i - 1] + u[i]
        y[i] = alpha[i - 1] + e[i]
    return y
def estimate(y):
    n=len(y)
    a = np.zeros(n)
    p = np.zeros(n)
    a[0] = 0
    p[0] = 10
    k = np.zeros(n)
    v = np.zeros(n)
    def f(mypa):
        q = np.fabs(mypa[0])
        co = np.fabs(mypa[1])
        w = 1
        z = 1
        likelihood = 0
        sigmae = 0
        for i in range(1, n):
            k[i] = (z * w * p[i - 1]) / ((z ** 2) * p[i - 1] + 1)
            p[i] = (w ** 2) * p[i - 1] - w * z * k[i] * p[i - 1] + q
            v[i] = y[i] - z * a[i - 1]
            a[i] = co + w * a[i - 1] + k[i] * v[i]
            sigmae = sigmae + ((v[i] ** 2) / ((z ** 2) * p[i - 1] + 1))
            likelihood = likelihood + 0.5 * math.log(2 * math.pi) + 0.5 + 0.5 * math.log((z ** 2) * p[i - 1] + 1)
            return (likelihood + 0.5 * n * math.log(sigmae / n))
    results=optimize.minimize(f,[0.5,0.2])
    v[0]=0
    w=1
    z=1
    q=np.fabs(results.x[0])
    co=np.fabs(results.x[1])
    sigmae=0
    for i in range(1,n):
        k[i] = (z * w * p[i - 1]) / ((z ** 2) * p[i - 1] + 1)
        p[i] = (w ** 2) * p[i - 1] - w * z * k[i] * p[i - 1] + q
        v[i] = y[i] - z * a[i - 1]
        a[i] = co + w * a[i - 1] + k[i] * v[i]
        sigmae = sigmae + ((v[i] ** 2) / ((z ** 2) * p[i - 1] + 1))
    sigmae=sigmae/len(y)
    sigmau=q*sigmae
    a=[sigmae,sigmau,co]
    return a
print(estimate(generate(100,0.6,0.2,1)))
```

### 运行截图

![](Weihai_Photo\19.png)

![](Weihai_Photo\20.png)![21](Weihai_Photo\21.png)

## single source

### 代码

```python
# Single source of error approach
# one source of error
n=100
e=math.sqrt(0.4)*np.random.randn(n)
gamma=0.1
con=0.05
y=np.zeros(n)
alpha=np.zeros(n)
y[0]=e[0];alpha[0]=u[0]
for i in range(1,100):
    y[i]=alpha[i-1]+e[i]
    alpha[i]=con+alpha[i-1]+gamma*e[i]
plt.plot(alpha)
plt.plot(y,'.')
plt.show()
a=np.zeros(100)
a[0]=y[0]
e=np.arange(0,100,1)
def f(mypa):
    gamma=np.fabs(mypa[0])
    co=np.fabs(mypa[1])
    for i in range(1,100):
        e[i]=y[i]-z*a[i-1]
        a[i]=co+a[i-1]+gamma*e[i]
    return np.sum(e**2/n)
myresults=optimize.minimize(f,[0.2,0.1])
print(myresults)
print(myresults.x[0])
print(myresults.x[1])
```

### 运行截图

![](Weihai_Photo\22.png)

![]()![23](Weihai_Photo\23.png)

## season

### 代码

```python
# Seasonally
n=102
e=math.sqrt(0.5)*np.random.randn(n)
u=math.sqrt(0.1)*np.random.randn(n)
y=np.zeros(n)
alpha=np.zeros(n)
factor=np.array([5,-4,2,-3])
s=4
def ceiling(factor,n):
    seasonal=np.zeros(n)
    for i in range(0,n-4,4):
        seasonal[i]=factor[0]
        seasonal[i+1]=factor[1]
        seasonal[i+2]=factor[2]
        seasonal[i+3]=factor[3]
    return seasonal
seasonal=ceiling(factor,n)
y[0]=e[0]+seasonal[0]
alpha[0]=u[0]
for i in range(1,n):
    y[i]=seasonal[i]+alpha[i-1]+e[i]
    alpha[i]=alpha[i-1]+u[i]
plt.plot(alpha)
plt.plot(y,'.')
plt.show()
y = [6, 2, 1, 3, 7, 3, 2, 4]
cma = np.zeros(8)
for i in range(2, 6):
    cma[i] = (0.5 * y[i - 2] + y[i - 1] + y[i] + y[i + 1] + 0.5 * y[i + 2]) / 4
    residuals = y - cma
c = np.hstack((y, cma, residuals))
print(c)
# multiplicative seasonality
n=103
s=4
e=math.sqrt(0.5)*np.random.randn(n)
u=math.sqrt(0.4)*np.random.randn(n)
y=np.zeros(n)
alpha=np.zeros(n)
factor=np.array([1.7,0.3,1.9,0.1])
def ceiling(factor,n):
    seasonal=np.zeros(n)
    for i in range(0,n-4,4):
        seasonal[i]=factor[0]
        seasonal[i+1]=factor[1]
        seasonal[i+2]=factor[2]
        seasonal[i+3]=factor[3]
    return seasonal
seasonal=ceiling(factor,100)
y[0]=e[0]
alpha[0]=u[0]+5
for i in range(1,n):
    y[i]=seasonal[i]*(alpha[i-1]+e[i])
    alpha[i]=alpha[i-1]+u[i]
'''below extract the seasonal component '''
def ceiling(factor,n):
    seasonal=np.zeros(n)
    for i in range(0,n-4,4):
        seasonal[i]=factor[0]
        seasonal[i+1]=factor[1]
        seasonal[i+2]=factor[2]
        seasonal[i+3]=factor[3]
    return seasonal
w=np.linspace(1/8,1/8,5)
w[1:s]=1/s
cma=np.ones(len(y))
for i in range(0,len(y)-s):
    cma[g+s/2]=np.sum(w*y[g:(g+s)])
    residual=y/cma
    factors=np.zeros(103)
    for seas in range(0,s):
        factors[seas]=np.mean(residual[seas:len(y)-s+seas,4])
newseries=y/ceiling(factors,ceiling(n/s))
c = np.hstack((y,newseries, alpha+e))
print(c)
```

### 运行截图

![](Weihai_Photo\24.png)

![](Weihai_Photo\25.png)

